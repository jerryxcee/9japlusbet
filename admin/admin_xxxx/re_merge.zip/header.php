<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>9Ja Plus Bet</title>
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <link href="assets/css/style.css" rel="stylesheet" />
</head>
 <!-- HEADER END-->
    <div class="navbar navbar-inverse set-radius-zero">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.html">

                    <img src="../../img/logo.png" width="200px" />
                </a>

            </div>

            <div class="left-div">
                <div class="user-settings-wrapper">
                    <ul class="nav">

                        <li class="dropdown">
                                <h2 style="color: #fff;">9Ja Plus Bet ADMIN DATABASE</h2>                            
                        </li>


                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- LOGO HEADER END-->
    <section class="menu-section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="navbar-collapse collapse ">
                        <ul id="menu-top" class="nav navbar-nav navbar-right">
                            <li><a class="menu-top-active" href="index.php" style="font-weight: bold;">Dashboard</a></li>
                            <li><a href="add_student.php" style="font-weight: bold;">Add Teams</a></li>
                            <li><a href="select_dep_to_add_score.php" style="font-weight: bold;">Add new games</a></li>
                            <li><a href="upload.php" style="font-weight: bold;">Add leagues</a></li>
                            <li><a href="report.php" style="font-weight: bold;">Users wallet</a></li>
                            <li><a href="dynamic.php" style="font-weight: bold;">Game results</a></li>
                            <li><a href="dynamic.php" style="font-weight: bold;">Update games</a></li>
                            <li><a href="read.php" style="font-weight: bold;">Withdrawers</a></li>
                            <li><a href="view_scores_table.php" style="font-weight: bold;">All users</a></li>
                            <li><a href="logout.php" style="font-weight: bold;">LogOut</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <body style="background-color: #eee;">