    <!-- CONTENT-WRAPPER SECTION END-->
    <footer style="margin-bottom: -100px;">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    &copy; 2018 9Ja Plus Bet
                </div>

            </div>
        </div>
    </footer>
    <!-- FOOTER SECTION END-->
    <!-- JAVASCRIPT AT THE BOTTOM TO REDUCE THE LOADING TIME  -->
    <!-- CORE JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.11.1.js"></script>
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="assets/js/bootstrap.js"></script>
</body>
</html>
